# Cyku Website QA Project

## QA Test Plan Introduction

The purpose of this QA test plan is to ensure that the Cyku Videos Drone Photography website is fully functional, easy to navigate, and presents a positive user experience. The website includes a home page, a real estate photo service page, a business commercial service page, and a contact page. It is important to ensure that the website's primary objective, which is to showcase the photographer/owner's portfolio, is met with the utmost professionalism and quality.

To achieve this, the testing objectives will include verifying that each photo and video is presented as expected, all page navigation links work as expected, the contact page functions correctly, and the website maintains a positive user perception of the business through proper logo and font usage and correct spelling without any grammatical issues. Furthermore, the website should be designed in such a way as to make it easy for users to understand the services provided and the benefits of choosing Cyku Videos Drone Photography. 

By conducting thorough testing and making necessary revisions, we can ensure that the website meets the needs of the business and its clients, and that it serves as an effective marketing tool that helps to grow the business and attract new clients.

## Summary

- Business Requirements
    - Easy and Successful Navigation throughout website
    - Successful photo and video presentation
    - A contact page that allows users to directly contact owner
    - Positive user perception of business via proper logo, font, spelling, and grammar
- Pages to be Tested
    - Home Page:
        - Logo and branding elements.
        - Presentation of photographer's portfolio.
        - Presentation of “about” section for photographer and business (2 separate sections)
    - Real Estate Photo Service Page:
        - Service details and pricing.
        - Sample real estate photos and videos.
    - Business Commercial Service Page:
        - Service description and benefits.
        - Sample commercial photography and videos.
    - Contact Page:
        - Contact form functionality.
        - Accuracy of contact details.
    - Navigation:
        - Links to all pages.
        - Header and footer navigation menus.
- Components to be Tested
    - Page navigation (header and within page)
    - Background videos play automatically on desktop browser
    - Background videos turn to still frames for mobile
    - Embedded videos play as expected on web browser and mobile
    - All photos maintain high quality on both web browser and mobile
    - Text boxes, dividers, media boxes, and all other website features are spaced correctly across web browsers and mobile
    - Social Media links successfully direct users to intended pages
    - Contact page text boxes for user input are functional
    - Error message pops up upon submission of contact page WITHOUT filling in “required” text boxes
    - A successful message notification is given to user when they have filled out all “required” text boxes and a message has been sent to the owner of website
    - Verify email has actually been received by owner of website
    

## Test Approach

Manual testing will be performed for functional, usability, and compatibility aspects.

Automated testing will be considered for repetitive tasks and regression testing.

## Test Environment

**Web Browsers:** 

Chrome and Edge

**Devices:** 

Custom PC - Desktop

MSI GS 65 Stealth Thin - Laptop

iPhone 12 Pro Max (iOS 16.6) - Mobile

Samsung Galaxy Tab S4 - Tablet

## Test Schedule

Project Start: 8/28/2023

Project Finish: 9/8/2023

Total Days (includes weekends): 12 Days

| Testing State | Days for Completion |
| --- | --- |
| Test Preparation | 3 (8/28 - 8/30) |
| Test Execution  | 5 (8/31 - 9/4) |
| Defect Reporting and Retesting | 3 (9/5 - 9/7) |
| Sign Off and Approval | 1 (9/8) |
| TOTAL | 12 |

## Test Cases and Scenarios

- HOME PAGE
    - Verify Logo image and sizing is correct
    - Verify images display as intended
    - Verify background videos play automatically on Web Browser
    - Verify background videos are switched to still frames for mobile
    - Verify text box and image spacing is correct; no overlap of text or images
    - Verify “scrolling text box” functions on both web browsers and mobile
    - 
- SERVICE PAGES
    - Verify service descriptions and pricings where applicable
    - Verify sample photos and videos display across both web browsers and mobile
    - Verify background videos play automatically on Web Browser
    - Verify background videos are switched to still frames for mobile
    - Verify text box and image spacing is correct; no overlap of text or images
    
- CONTACT PAGE
    - Verify text can be entered into text boxes
    - Verify text box and image spacing is correct; no overlap of text or images
    - Verify error message pops up if all required text boxes are not filled in when user presses submit
    - Verify form submission response
    - Verify client receives an email from contact page
    
- NAVIGATION
    - Click all page links in header
    - Verify that clicking the logo itself directs user to Home Page
    - Click all navigation links within pages
        - Contact page link after pricing section in real estate service page
        - Contact page link at bottom of business commercial page
    - Click all social media links
        - Instagram and Tik Tok in header
        - Scroll feature on Home page
        - Instagram link to @grace.et.paix in business commercial page
        - Instagram and Tik Tok in the middle of contact page
    

## Risk Assessment

Risk: Cross-browser compatibility issues

Impact: inconsistent user experience

Mitigation: test on various browsers and devices

## Test Deliverables

Test Case Documentation - Jira

Defect Reports with screenshots - Jira

Test Summary Report with Requirement Traceability Matrix - will be attached as a separate document once project is complete

## Test Execution & Defect Management

All information regarding test cases and defects found will be done in Jira

## Sign-off and Approval

Project will be completed once Owner of [cykuvideos.com](http://cykuvideos.com) approves of the work done and sign-offs that all needs have been met as per the business requirements. 

Name of Client:

Date:

# Timeline:

1. Started brainstorming idea when I completed Udemy course and started brainstorming 8/27/23
2. started writing sample/ template test plan 8/28/23 
3. Finished test plan, created Jira project, and began creating epics/stories 8/29/23 
4. Created all epics and stories with priorities set, set release date, created sprints, and began Home and Contact Sprint. Grooming of included stories was completed as well. 8/30/23
5. Began creating test cases